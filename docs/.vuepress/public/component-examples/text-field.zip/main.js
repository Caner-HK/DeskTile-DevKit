let request=0, value='', down=null;
function onPointer(event,pointer){
  if(pointer.target!==DeskTile.byId('name')||request)return;
  if(event===12){down={x:pointer.x,y:pointer.y};return;}
  if(event===15){down=null;return;}
  if(!down)return;
  if(Math.abs(pointer.x-down.x)>=8||Math.abs(pointer.y-down.y)>=8){down=null;return;}
  if(event===14){down=null;if(pointer.localX>=0&&pointer.localX<752&&pointer.localY>=0&&pointer.localY<52){const id=DeskTile.keyboard(JSON.stringify({title:'名称',initial:value,maximum_length:512}));if(id>0)request=id;}}
}
function onRequestComplete(id,result,data){if(id!==request)return;request=0;if(result===0){value=DeskTile.utf8Decode(data);DeskTile.setText(DeskTile.byId('name'),0,value);}}
