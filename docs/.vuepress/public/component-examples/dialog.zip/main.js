function onEvent(event,target){if(event===0&&['open','rename','delete','cancel'].some(function(id){return target===DeskTile.byId(id);}))DeskTile.setBoolean(DeskTile.byId('confirm'),4,false);}
