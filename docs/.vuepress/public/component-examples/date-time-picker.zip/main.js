function enter(){DeskTile.configureDateTimePicker(DeskTile.byId('date'),{mode:'both',symbols:'arrows',date:'2026-10-29',time:'12:34',dateLabel:'日期',timeLabel:'时间',units:['年','月','日','时','分']});}
