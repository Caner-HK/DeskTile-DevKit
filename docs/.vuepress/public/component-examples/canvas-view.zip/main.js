function enter(){
  const bytes=new ArrayBuffer(60), view=new DataView(bytes);
  const bars=[[40,100,96,100,0xFF9900],[180,40,96,160,0x168471],[320,70,96,130,0x3765FF]];
  bars.forEach(function(b,i){const p=i*20;view.setUint8(p,1);view.setUint16(p+2,20,true);for(let k=0;k<4;k++)view.setInt16(p+4+k*2,b[k],true);view.setUint32(p+12,b[4],true);});
  DeskTile.setBytes(DeskTile.byId('chart'),29,bytes);
}
