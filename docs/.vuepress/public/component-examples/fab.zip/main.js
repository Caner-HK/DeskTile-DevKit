function onEvent(event,target){if(event===0&&target===DeskTile.byId('fab'))DeskTile.keyboard(JSON.stringify({title:'新建便签',initial:'',maximum_length:512}));}
