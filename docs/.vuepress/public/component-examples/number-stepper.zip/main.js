let count=10;
function refresh(){DeskTile.setText(DeskTile.byId('count-value'),0,String(count));DeskTile.setBoolean(DeskTile.byId('count-up'),5,count<20);DeskTile.setBoolean(DeskTile.byId('count-down'),5,count>0);}
function enter(){refresh();}
function onEvent(event,target){if(event!==0)return;if(target===DeskTile.byId('count-up'))count=Math.min(20,count+1);else if(target===DeskTile.byId('count-down'))count=Math.max(0,count-1);else return;refresh();}
